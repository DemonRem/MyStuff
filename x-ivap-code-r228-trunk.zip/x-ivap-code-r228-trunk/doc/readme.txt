Readme for X-IvAp

Installation

Just copy the contents of the for_plugins_folder into the Resources/plugins
folder of your X-Plane installation directory. To avoid conflicts you should
disable the XSquawkBox and IVAORW plugins while you are using X-IvAp. 

If you are new to X-IvAp, take a look at the introduction.

Have fun!
