The folders Mac and Win were provided in a package,
that should have contained Windows and Linux library
files. These files are in the XPlane SDK which is
available at http://www.xsquawkbox.net/xpsdk

XPWidgetsExLib* files are a part of the advanced
plugin examples, available from the same site.
However, at the moment the WidgetsExLib is not used.