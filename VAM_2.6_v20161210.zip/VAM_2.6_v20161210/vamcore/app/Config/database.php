<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'xxxxxx',
		'password' => 'xxxxxx',
		'database' => 'xxxxxx',
		'encoding' => 'utf8'
	);
}