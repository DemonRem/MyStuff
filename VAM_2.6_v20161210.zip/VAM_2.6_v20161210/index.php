<?php
  header( 'Location: ./vam/index.php?lang=en' );
  exit();
?>